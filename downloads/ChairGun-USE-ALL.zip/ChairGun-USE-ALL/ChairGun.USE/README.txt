ChairGun4 README.txt

This program was decompiled - reverse engineered - from the original
Java 6 Source.

========================================================================

Due to changes that have taken place in both Java, and in its licensing, 
since ChairGun was last released by its Original Developer, this bundle 
does not include an installer to automate the installation process for 
you.

PLEASE FOLLOW THE INSTRUCTIONS IN THE INSTALL PDF FILE FOR THE OPERATING
SYSTEM THAT YOU WOULD LIKE TO RUN THIS ON.

========================================================================

There are two variants of this program.  

ChairGunJ8.jar – is for running it with Java 8.
ChairGunJ9P.jar – is for running it with Java 9 or above.

Either should work fine on Windows or Linux using Java 8 or above.

The variants are primarily for Mac OS.  On a Mac, you must run ChairGunJ8.jar with Java 8, and you must run ChairGunJ9P.jar with Java 9 or above.

But on Windows or Linux, it really should not matter which variant you use, as long as you execute it with Java 8 or above.

========================================================================

--

For Support, please contact: ChairGun.USE@hotmail.com

--

PLEASE DO NOT CONTACT THE ORIGINAL DEVELOPER FOR SUPPORT.  

They have no way of assisting you, as they do not even have access to the
updated source code for this program.





