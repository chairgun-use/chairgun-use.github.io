#!/bin/sh

# NOTE: You may need to edit this to match your system.

# Lines starting with a pound sign (#) are simply comments, except for the
# first line, and will not be executed.  There are only two lines below here
# that must be set.


# You must set the working directory to the location you will be running this 
# from. All of the ChairGun files and folders must reside in this directory.

# If you put the ChairGun.USE directory in your home directory, this should
# work.

cd ~/ChairGun.USE/

# Otherwise, change the line above to where you installed it.


# If you would like to use a specific version of Java, then edit the following
# line to match the path to the version of Java you want to use.

# For Example:

# /usr/lib/jvm/jre1.8.0_202/bin/java -jar ChairGun.jar

# Without the pound sign in front.


# Otherwise, this should work:

java -jar ChairGun.jar



BE SURE TO EITHER CHANGE "ChairGun.jar" above to "ChairGunJ8.jar" or "ChairGunJ9P.jar", OR rename the jar file you would like to use to "ChairGun.jar".


