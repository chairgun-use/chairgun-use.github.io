#!/bin/sh

# NOTE: You may need to edit this to match your system.

# Lines starting with a pound sign (#) are simply comments, except for the
# first line, and will not be executed.  There are only two lines below here
# that must be set.


# You must set the working directory to the location you will be running this 
# from. All of the ChairGun files and folders must reside in this directory.

# If you put the ChairGun.USE directory in your home directory, this should
# work.

cd ~/ChairGun.USE/


# You must edit the following line to match the path to Java that you have on 
# your system.  It may be different than this.

/usr/lib/jvm/jre1.8.0_202/bin/java -jar ChairGun.jar

# Note: If you run "java -version" and your system shows that you already have 
# Oracle Java 1.8 installed, you can change the above line to simply:

# java -jar ChairGun.jar

# Without the pound sign in front.

