REM This launches ChairGun in Windows.

REM This is for ADVANCED USERS ONLY. 99% OF USERS WILL NOT NEED TO USE THIS.

REM If you are an advanced user, and have multiple Java Runtime Environments on your 
REM system, you may need to modify this batch file, and use it to launch ChairGun, 
REM instead of simply double-clicking your ChairGun.jar file.

REM The important things are that you will need to set the active directory to where 
REM the ChairGun program files are located.  And you will need to specify the path
REM to the java executable.

REM For example: C:\Program Files\Java\jre1.8.0_202\bin\javaw.exe



cd C:\Users\YOUR_USER_NAME\Documents\ChairGun.USE

C:\YOUR\PATH\TO\JAVA\java -jar ChairGun.jar



BE SURE TO EITHER CHANGE "ChairGun.jar" above to "ChairGunJ8.jar" or "ChairGunJ9P.jar", OR rename the jar file you would like to use to "ChairGun.jar".


