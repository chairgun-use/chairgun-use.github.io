ChairGun4 README.txt

This program was decompiled - reverse engineered - from the original
Java 6 Source.

========================================================================
You MUST Use * Oracle * Java 8 to run this program.

***** Newer Versions of Java will not run this program properly. *****

***** OpenJava will not run this program properly on some systems. *****

You can install and run multiple versions of Java on the same system,
if you find that is necessary for your particular circumstances. 

However, you must run this program using Oracle Java 8, regardless of
whatever other Java runtimes you may have installed on your system.
========================================================================

Due to changes that have taken place in both Java, and in its licensing, 
since ChairGun was last released by its Original Developer, this bundle 
does not include an installer to automate the installation process for 
you.

PLEASE FOLLOW THE INSTRUCTIONS IN THE INSTALL PDF FILE FOR THE OPERATING
SYSTEM THAT YOU WOULD LIKE TO RUN THIS ON.

--

For Support, please contact: ChairGun.USE@hotmail.com

--

PLEASE DO NOT CONTACT THE ORIGINAL DEVELOPER FOR SUPPORT.  

They have no way of assisting you, as they do not even have access to the
updated source code for this program.


